package com.example.msalmacen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAlmacenApplicationTests {

    @Test
    void contextLoads() {
    }

}
